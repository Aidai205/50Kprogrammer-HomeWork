var friendsName = "Aidai"
let age = 12
const favoriteBook = "Harry Potter"

friendsName = "Tima"
age = 13


console. log (friendsName, age, favoriteBook)

const summ= 5 ** 155

console.log (summ)



